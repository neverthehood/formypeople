<?php
$error="";
require_once($_SERVER['DOCUMENT_ROOT'].'/_core/core.php');