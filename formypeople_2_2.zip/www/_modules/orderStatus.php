<?php
function orderStatus(){
	return coffee::orderStatus();
}